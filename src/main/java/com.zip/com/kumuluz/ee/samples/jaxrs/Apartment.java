package com.kumuluz.ee.samples.jaxrs;

/**
 * @author Matej Dolenc
 */
public class Apartment {

    private String id;
    private String numOfBeds;
    private String customerId;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNumOfBeds() {
        return numOfBeds;
    }

    public void setNumOfBeds(String numOfBeds) {
        this.numOfBeds = numOfBeds;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }
}
